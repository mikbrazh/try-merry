var fixturePath = 'base/test/spec/fixtures',
    tabsFixture = 'tabs.fixture.html';
